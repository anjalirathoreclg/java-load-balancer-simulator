// Run with: java ProjectTests. These tests need no testing library.
public class ProjectTests {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static void rejects(Runnable action, String message) {
        boolean rejected = false;
        try { action.run(); } catch (IllegalArgumentException exception) { rejected = true; }
        check(rejected, message);
    }
    public static void main(String[] args) {
        SimpleList<Integer> list = new SimpleList<>();
        for (int i = 0; i < 20; i++) list.add(i);
        list.remove(0);
        check(list.size() == 19 && list.get(0) == 1, "Dynamic array growth/deletion");
        RequestQueue queue = new RequestQueue();
        Request first = new Request("A", 0, 2), second = new Request("B", 0, 1);
        queue.enqueue(first); queue.enqueue(second);
        check(queue.dequeue() == first && queue.dequeue() == second && queue.dequeue() == null, "FIFO");
        queue.enqueue(first); check(queue.dequeue() == first, "Queue reuse after empty");
        RequestTable table = new RequestTable();
        table.put(new Request("Aa", 0, 1)); table.put(new Request("BB", 0, 1));
        check(table.get("Aa") != null && table.get("BB") != null, "Hash collisions");

        Simulator rr = new Simulator(new int[]{1, 1}, Algorithm.ROUND_ROBIN);
        rr.addRequest("A", 2); rr.addRequest("B", 1); rr.addRequest("C", 1);
        check(rr.requests.get("A").serverId == 1 && rr.requests.get("B").serverId == 2, "Round Robin");
        check(rr.pending.size() == 1 && rr.maximumQueueLength == 1, "Capacity and queue metric");
        rr.advanceTime(1);
        check(rr.requests.get("C").serverId == 2 && rr.requests.get("C").remainingTime == 1, "Automatic assignment timing");
        rr.advanceTime(1);
        check(rr.completed.size() == 3 && rr.requests.get("C").waiting() == 1, "Completion and waiting formula");
        rejects(() -> rr.addRequest("A", 1), "Completed IDs remain reserved");
        rejects(() -> rr.addRequest("X", 0), "Positive duration");

        Simulator ll = new Simulator(new int[]{3, 3}, Algorithm.LEAST_LOAD);
        ll.addRequest("A", 5); ll.addRequest("B", 1); ll.addRequest("C", 1);
        check(ll.requests.get("A").serverId == 1 && ll.requests.get("B").serverId == 2
            && ll.requests.get("C").serverId == 2, "Heap load selection and ID ties");

        Simulator failure = new Simulator(new int[]{1}, Algorithm.LEAST_LOAD);
        failure.addRequest("A", 3); failure.addRequest("B", 1); failure.advanceTime(1);
        failure.failServer(1); failure.advanceTime(2);
        check(!failure.finishWorkload(), "All offline does not loop forever");
        rejects(() -> failure.failServer(1), "Reject repeated failure");
        failure.recoverServer(1);
        check(failure.requests.get("B").status == Status.RUNNING, "Existing queue comes before failed request");
        check(failure.requests.get("A").remainingTime == 2, "Failure preserves progress");
        failure.finishWorkload();
        check(failure.requests.get("A").waiting() == 3, "Failure downtime included in waiting");
        rejects(() -> failure.recoverServer(1), "Reject repeated recovery");

        // A batch pending assignment must rebuild the heap each time.
        Simulator batch = new Simulator(new int[]{4, 4}, Algorithm.LEAST_LOAD);
        batch.failServer(1); batch.failServer(2);
        batch.addRequest("A", 8); batch.addRequest("B", 1); batch.addRequest("C", 1);
        batch.recoverServer(1); batch.recoverServer(2);
        batch.addRequest("D", 1); batch.addRequest("E", 1);
        check(batch.requests.get("D").serverId == 2 && batch.requests.get("E").serverId == 2, "Heap updated after assignment");

        Simulator many = new Simulator(new int[]{3, 3}, Algorithm.LEAST_LOAD);
        many.failServer(1); many.failServer(2);
        many.addRequest("A", 8); many.addRequest("B", 1); many.addRequest("C", 1);
        // Test fixture makes both servers available before one assignment loop.
        many.servers.get(0).online = true;
        many.servers.get(1).online = true;
        many.assignPending();
        check(many.requests.get("A").serverId == 1 && many.requests.get("B").serverId == 2
            && many.requests.get("C").serverId == 2, "Rebuild inside a batch assignment loop");
        rejects(() -> many.failServer(99), "Unknown server rejected");
        rejects(() -> new Simulator(new int[]{0}, Algorithm.ROUND_ROBIN), "Invalid capacity rejected");

        SimpleList<WorkloadEvent> events = new SimpleList<>();
        events.add(new WorkloadEvent("ADD", "R", 2));
        events.add(new WorkloadEvent("TIME", null, 1));
        Simulator a = Main.replay(new int[]{1}, events, Algorithm.ROUND_ROBIN);
        Simulator b = Main.replay(new int[]{1}, events, Algorithm.LEAST_LOAD);
        a.finishWorkload();
        check(b.requests.get("R").remainingTime == 1 && b.time == 1, "Independent replay objects");
        b.finishWorkload();
        check(a.completed.size() == 1 && b.completed.size() == 1, "Both replays finish");
        // Scale-up should assign waiting work, respect the limit and preserve IDs.
        Simulator scaling = new Simulator(new int[]{1}, Algorithm.AUTO);
        scaling.addRequest("S1", 8);
        scaling.addRequest("S2", 1);
        check(scaling.pending.size() == 1, "Scaling initially disabled");
        scaling.configureAutoscaling(true, 2, 1);
        check(scaling.servers.size() == 2 && scaling.pending.isEmpty(), "Enabling scales queued work");
        scaling.addRequest("S3", 2);
        check(scaling.servers.size() == 2 && scaling.pending.size() == 1, "Maximum server limit");
        scaling.failServer(2);
        scaling.recoverServer(2);
        check(scaling.requests.get("S3").serverId == 2, "Recover scaled server with FIFO preserved");
        scaling.configureAutoscaling(false, 2, 1);
        check(scaling.servers.size() == 2 && !scaling.autoscaling, "Disabling does not remove servers");
        rejects(() -> scaling.configureAutoscaling(true, 1, 1), "Reject limit below current size");
        rejects(() -> scaling.configureAutoscaling(true, 101, 1), "Reject excessive limit");
        rejects(() -> scaling.configureAutoscaling(true, 2, 0), "Reject invalid scale capacity");

        Simulator auto = new Simulator(new int[]{3, 3}, Algorithm.AUTO);
        auto.addRequest("A", 5);
        check(auto.selectedAlgorithm == Algorithm.ROUND_ROBIN, "Similar work selects round robin");
        auto.addRequest("B", 1);
        check(auto.selectedAlgorithm == Algorithm.LEAST_LOAD && auto.requests.get("B").serverId == 2,
            "Variable durations select least load");
        Simulator balanced = new Simulator(new int[]{3, 3}, Algorithm.AUTO);
        balanced.addRequest("A", 1); balanced.addRequest("B", 1);
        check(balanced.selectedAlgorithm == Algorithm.ROUND_ROBIN, "Balanced similar durations");
        Simulator imbalance = new Simulator(new int[]{3, 3}, Algorithm.AUTO);
        imbalance.addRequest("A", 3); imbalance.addRequest("B", 3);
        check(imbalance.selectedAlgorithm == Algorithm.LEAST_LOAD, "Equal durations with uneven loads");
        Simulator offlineScale = new Simulator(new int[]{1}, Algorithm.AUTO);
        offlineScale.failServer(1);
        offlineScale.configureAutoscaling(true, 2, 1);
        offlineScale.addRequest("R", 1);
        check(offlineScale.requests.get("R").serverId == 2 && offlineScale.finishWorkload(),
            "Scale-up when all original servers offline");

        SimpleList<WorkloadEvent> scalingEvents = new SimpleList<>();
        scalingEvents.add(new WorkloadEvent("SCALE_ON", "1", 3));
        scalingEvents.add(new WorkloadEvent("ADD", "A", 3));
        scalingEvents.add(new WorkloadEvent("ADD", "B", 1));
        scalingEvents.add(new WorkloadEvent("SCALE_OFF", "1", 3));
        Simulator replayRR = Main.replay(new int[]{1}, scalingEvents, Algorithm.ROUND_ROBIN);
        Simulator replayLL = Main.replay(new int[]{1}, scalingEvents, Algorithm.LEAST_LOAD);
        check(replayRR.servers.size() == 2 && replayLL.servers.size() == 2,
            "Both replays apply identical scaling settings");
        check(!replayRR.autoscaling && !replayLL.autoscaling, "Replay scaling toggle");
        replayRR.finishWorkload(); replayLL.finishWorkload();
        check(replayRR.completed.size() == 2 && replayLL.completed.size() == 2,
            "Scaled replay completion");
        System.out.println("PASS: " + checks + " checks.");
    }
}
