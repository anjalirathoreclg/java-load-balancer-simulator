class Simulator {
    final SimpleList<Server> servers = new SimpleList<>();
    final RequestQueue pending = new RequestQueue();
    final RequestTable requests = new RequestTable();
    final CompletionStack completed = new CompletionStack();
    final ServerHeap heap = new ServerHeap();
    final Algorithm algorithm;
    Algorithm selectedAlgorithm;
    String selectionReason = "No pending batch yet.";
    boolean autoscaling;
    boolean showMessages;
    int maximumServers, newServerCapacity = 1;
    int scaledServers;
    long time;
    int nextServerIndex, maximumQueueLength;

    Simulator(int[] capacities, Algorithm algorithm) {
        if (capacities.length == 0) throw new IllegalArgumentException("At least one server is required.");
        this.algorithm = algorithm;
        this.selectedAlgorithm = algorithm == Algorithm.AUTO ? Algorithm.ROUND_ROBIN : algorithm;
        this.maximumServers = capacities.length;
        for (int i = 0; i < capacities.length; i++) {
            if (capacities[i] < 1) throw new IllegalArgumentException("Capacity must be positive.");
            servers.add(new Server(i + 1, capacities[i]));
        }
        heap.rebuild(servers);
    }

    void addRequest(String id, int duration) {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("ID cannot be empty.");
        if (duration < 1) throw new IllegalArgumentException("Processing time must be at least 1.");
        Request request = new Request(id, time, duration);
        requests.put(request); // Duplicate check happens before the queue changes.
        pending.enqueue(request);
        assignPending();
        recordQueueLength();
    }

    private void recordQueueLength() {
        // Measure requests still waiting after automatic assignment.
        if (pending.size() > maximumQueueLength) maximumQueueLength = pending.size();
    }

    private Server chooseServer() {
        if (selectedAlgorithm == Algorithm.LEAST_LOAD) return heap.minimum();
        for (int offset = 0; offset < servers.size(); offset++) {
            int index = (nextServerIndex + offset) % servers.size();
            Server server = servers.get(index);
            if (server.available()) {
                nextServerIndex = (index + 1) % servers.size();
                return server;
            }
        }
        return null;
    }

    // Configure scale-up only. Existing servers are never removed.
    void configureAutoscaling(boolean enabled, int limit, int capacity) {
        if (limit < servers.size() || limit > 100)
            throw new IllegalArgumentException("Maximum servers must be between current count and 100.");
        if (capacity < 1 || capacity > 100)
            throw new IllegalArgumentException("New server capacity must be 1-100.");
        autoscaling = enabled;
        maximumServers = limit;
        newServerCapacity = capacity;
        assignPending();
        recordQueueLength();
    }

    // Choose once per nonempty assignment batch, considering pending and running work.
    private void selectAlgorithm() {
        if (algorithm != Algorithm.AUTO) return;
        int minimum = pending.minimumDuration();
        int maximum = pending.maximumDuration();
        long minimumLoad = Long.MAX_VALUE, maximumLoad = 0;
        int online = 0;
        for (int i = 0; i < servers.size(); i++) {
            Server server = servers.get(i);
            if (!server.online) continue;
            online++;
            minimumLoad = Math.min(minimumLoad, server.load());
            maximumLoad = Math.max(maximumLoad, server.load());
            for (int j = 0; j < server.running.size(); j++) {
                int duration = server.running.get(j).remainingTime;
                minimum = Math.min(minimum, duration);
                maximum = Math.max(maximum, duration);
            }
        }
        // A 2:1 duration ratio or a two-unit load spread is a simple heuristic.
        if ((long) maximum >= 2L * minimum) {
            selectedAlgorithm = Algorithm.LEAST_LOAD;
            selectionReason = "Remaining durations vary by at least 2:1.";
        } else if (online > 1 && maximumLoad - minimumLoad >= 2) {
            selectedAlgorithm = Algorithm.LEAST_LOAD;
            selectionReason = "Online server loads differ by at least 2 units.";
        } else {
            selectedAlgorithm = Algorithm.ROUND_ROBIN;
            selectionReason = "Durations are similar and server loads are reasonably balanced.";
        }
        if (showMessages) System.out.println("Auto-selected " + selectedAlgorithm + ": " + selectionReason);
    }

    void assignPending() {
        if (pending.isEmpty()) return;
        selectAlgorithm();
        heap.rebuild(servers);
        while (!pending.isEmpty()) {
            Server server = chooseServer();
            if (server == null) {
                if (!autoscaling || servers.size() >= maximumServers) break;
                // No eligible server: create capacity even when all old servers are offline.
                Server added = new Server(servers.size() + 1, newServerCapacity);
                servers.add(added);
                scaledServers++;
                if (showMessages) System.out.println("Autoscaling: added S" + added.id
                    + " with capacity " + added.capacity + ".");
                heap.rebuild(servers);
                continue;
            }
            Request request = pending.dequeue();
            request.status = Status.RUNNING;
            request.serverId = server.id;
            server.running.add(request);
            // Every assignment changes load and possibly fills a server.
            heap.rebuild(servers);
        }
    }

    void advanceTime(int ticks) {
        if (ticks < 1) throw new IllegalArgumentException("Ticks must be positive.");
        for (int tick = 0; tick < ticks; tick++) {
            time++;
            for (int i = 0; i < servers.size(); i++) {
                Server server = servers.get(i);
                // Every running request gets one processing unit per tick.
                int j = 0;
                while (j < server.running.size()) {
                    Request request = server.running.get(j);
                    request.remainingTime--;
                    if (request.remainingTime == 0) {
                        request.status = Status.COMPLETED;
                        request.completionTime = time;
                        request.serverId = -1;
                        completed.push(request);
                        server.running.remove(j);
                        // Do not increment j: another request moved into this position.
                    } else j++;
                }
            }
            assignPending(); // Newly assigned requests start processing next tick.
        }
    }

    private Server serverById(int id) {
        if (id < 1 || id > servers.size()) throw new IllegalArgumentException("Unknown server ID.");
        return servers.get(id - 1);
    }

    void failServer(int id) {
        Server server = serverById(id);
        if (!server.online) throw new IllegalArgumentException("Server is already offline.");
        server.online = false;
        // Sort returned requests using simple insertion sort: arrival, then ID.
        Request[] returned = new Request[server.running.size()];
        for (int i = 0; i < returned.length; i++) returned[i] = server.running.get(i);
        for (int i = 1; i < returned.length; i++) {
            Request current = returned[i];
            int j = i - 1;
            while (j >= 0 && comesAfter(returned[j], current)) {
                returned[j + 1] = returned[j]; j--;
            }
            returned[j + 1] = current;
        }
        for (int i = 0; i < returned.length; i++) {
            returned[i].status = Status.WAITING;
            returned[i].serverId = -1;
            pending.enqueue(returned[i]); // Normal queue: failure returns go to REAR.
        }
        server.running.clear();
        assignPending();
        recordQueueLength();
    }

    private boolean comesAfter(Request a, Request b) {
        if (a.arrivalTime != b.arrivalTime) return a.arrivalTime > b.arrivalTime;
        return a.id.compareTo(b.id) > 0;
    }

    void recoverServer(int id) {
        Server server = serverById(id);
        if (server.online) throw new IllegalArgumentException("Server is already online.");
        server.online = true;
        assignPending();
    }

    boolean hasOnlineServer() {
        for (int i = 0; i < servers.size(); i++) if (servers.get(i).online) return true;
        return false;
    }

    boolean finishWorkload() {
        assignPending();
        while (completed.size() < requests.size()) {
            if (!hasOnlineServer()) return false; // Avoid an endless comparison.
            advanceTime(1);
        }
        return true;
    }

    void displayServers() {
        for (int i = 0; i < servers.size(); i++) {
            Server s = servers.get(i);
            System.out.println("S" + s.id + " | " + (s.online ? "ONLINE" : "OFFLINE")
                + " | capacity=" + s.capacity + " | running=" + s.running.size() + " | load=" + s.load());
            for (int j = 0; j < s.running.size(); j++) System.out.println("  " + s.running.get(j));
        }
    }

    void report() {
        int count = completed.size();
        System.out.println("Algorithm: " + algorithm + " | Time: " + time);
        if (algorithm == Algorithm.AUTO)
            System.out.println("Last batch: " + selectedAlgorithm + " | " + selectionReason);
        System.out.println("Autoscaling: " + (autoscaling ? "ON" : "OFF")
            + " | Servers: " + servers.size() + " | Limit: " + maximumServers
            + " | Added: " + scaledServers);
        System.out.println("Total=" + requests.size() + " | Completed=" + count
            + " | Waiting=" + pending.size() + " | Running=" + (requests.size() - count - pending.size()));
        System.out.println("Maximum waiting queue length: " + maximumQueueLength);
        if (count == 0) System.out.println("Average times: N/A (no completed requests).");
        else System.out.printf("Average waiting: %.2f | Average turnaround: %.2f%n",
            (double) completed.totalWaiting() / count, (double) completed.totalTurnaround() / count);
    }
}
