enum Status { WAITING, RUNNING, COMPLETED }
enum Algorithm { ROUND_ROBIN, LEAST_LOAD, AUTO }

class Request {
    final String id;
    final long arrivalTime;
    final int totalTime;
    int remainingTime;
    Status status = Status.WAITING;
    int serverId = -1;
    long completionTime = -1;
    Request(String id, long arrivalTime, int totalTime) {
        this.id = id; this.arrivalTime = arrivalTime;
        this.totalTime = totalTime; this.remainingTime = totalTime;
    }
    long turnaround() { return completionTime - arrivalTime; }
    long waiting() { return turnaround() - totalTime; }
    public String toString() {
        return id + " | " + status + " | arrival=" + arrivalTime
            + " | total=" + totalTime + " | remaining=" + remainingTime
            + " | server=" + (serverId == -1 ? "-" : "S" + serverId)
            + " | completion=" + (completionTime == -1 ? "-" : completionTime);
    }
}

class Server {
    final int id, capacity;
    boolean online = true;
    final SimpleList<Request> running = new SimpleList<>();
    Server(int id, int capacity) { this.id = id; this.capacity = capacity; }
    boolean available() { return online && running.size() < capacity; }
    long load() {
        long sum = 0;
        for (int i = 0; i < running.size(); i++) sum += running.get(i).remainingTime;
        return sum;
    }
}

// Immutable event data, rather than mutable Request/Server references.
class WorkloadEvent {
    final String type, requestId;
    final int value;
    WorkloadEvent(String type, String requestId, int value) {
        this.type = type; this.requestId = requestId; this.value = value;
    }
}
