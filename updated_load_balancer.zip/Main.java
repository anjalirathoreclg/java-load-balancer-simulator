import java.util.Scanner; // Input only; no predefined collections are used.

public class Main {
    private static final Scanner input = new Scanner(System.in);

    // Read a whole line so non-numeric input does not break the menu.
    private static int readInt(String message, int minimum, int maximum) {
        while (true) {
            System.out.print(message);
            try {
                int value = Integer.parseInt(readLine());
                if (value >= minimum && value <= maximum) return value;
            } catch (NumberFormatException exception) {
                // Explain the valid range and ask again.
            }
            System.out.println("Enter a whole number from " + minimum + " to " + maximum + ".");
        }
    }

    private static String readLine() {
        if (!input.hasNextLine()) throw new IllegalStateException("Input closed.");
        return input.nextLine().trim();
    }

    public static void main(String[] args) {
        try { runMenu(); }
        catch (IllegalStateException exception) { System.out.println("Input closed. Goodbye!"); }
        finally { input.close(); }
    }

    private static void runMenu() {
        System.out.println("LOAD BALANCER SIMULATOR - custom data structures");
        int count = readInt("Number of servers (1-100): ", 1, 100);
        int[] capacities = new int[count]; // Immutable initial setup for replay.
        for (int i = 0; i < count; i++)
            capacities[i] = readInt("Capacity of S" + (i + 1) + " (1-100): ", 1, 100);
        int choice = readInt("Algorithm: 1. Round Robin  2. Least Load  3. Auto: ", 1, 3);
        Simulator simulation = new Simulator(capacities,
            choice == 1 ? Algorithm.ROUND_ROBIN : choice == 2 ? Algorithm.LEAST_LOAD : Algorithm.AUTO);
        simulation.showMessages = true;
        SimpleList<WorkloadEvent> events = new SimpleList<>();

        while (true) {
            System.out.println("\n========== LOAD BALANCER SIMULATOR ==========");
            System.out.println("Current time: " + simulation.time + " | Algorithm: " + simulation.algorithm);
            System.out.println("1. Add new request\n2. Advance time\n3. Display server status"
                + "\n4. Display pending requests\n5. Search request by ID"
                + "\n6. Completed requests - latest first\n7. Fail a server\n8. Recover a server"
                + "\n9. Performance report\n10. Compare both algorithms\n11. Configure autoscaling ON/OFF\n0. Exit");
            int option = readInt("Choice: ", 0, 11);
            if (option == 0) { System.out.println("Goodbye!"); return; }
            try {
                switch (option) {
                    case 1: {
                        System.out.print("Request ID (case-sensitive): ");
                        String id = readLine();
                        int duration = readInt("Processing time (1-100000): ", 1, 100000);
                        simulation.addRequest(id, duration);
                        events.add(new WorkloadEvent("ADD", id, duration));
                        System.out.println(simulation.requests.get(id));
                        break;
                    }
                    case 2: {
                        int ticks = readInt("Ticks to advance (1-100000): ", 1, 100000);
                        simulation.advanceTime(ticks);
                        events.add(new WorkloadEvent("TIME", null, ticks));
                        System.out.println("Time is now " + simulation.time + ".");
                        break;
                    }
                    case 3: simulation.displayServers(); break;
                    case 4: simulation.pending.display(); break;
                    case 5: {
                        System.out.print("Request ID: ");
                        Request request = simulation.requests.get(readLine());
                        System.out.println(request == null ? "Request not found." : request);
                        break;
                    }
                    case 6: simulation.completed.display(); break;
                    case 7: {
                        int id = readInt("Server ID (number only): ", 1, simulation.servers.size());
                        simulation.failServer(id);
                        events.add(new WorkloadEvent("FAIL", null, id));
                        System.out.println("Server failed; unfinished requests returned to queue rear.");
                        break;
                    }
                    case 8: {
                        int id = readInt("Server ID (number only): ", 1, simulation.servers.size());
                        simulation.recoverServer(id);
                        events.add(new WorkloadEvent("RECOVER", null, id));
                        System.out.println("Server recovered; waiting requests assigned where possible.");
                        break;
                    }
                    case 9: simulation.report(); break;
                    case 10: compare(capacities, events); break;
                    case 11: {
                        int enabled = readInt("Autoscaling: 0. OFF  1. ON: ", 0, 1);
                        int limit = simulation.maximumServers;
                        int capacity = simulation.newServerCapacity;
                        if (enabled == 1) {
                            limit = readInt("Maximum total servers (" + simulation.servers.size()
                                + "-100): ", simulation.servers.size(), 100);
                            capacity = readInt("Capacity of new servers (1-100): ", 1, 100);
                        }
                        simulation.configureAutoscaling(enabled == 1, limit, capacity);
                        // Store settings in the same event stream used by comparison.
                        events.add(new WorkloadEvent(enabled == 1 ? "SCALE_ON" : "SCALE_OFF",
                            "" + capacity, limit));
                        System.out.println("Autoscaling " + (enabled == 1 ? "ON" : "OFF") + ".");
                        break;
                    }
                    default: break;
                }
            } catch (IllegalArgumentException exception) {
                System.out.println("Cannot perform action: " + exception.getMessage());
                // Invalid actions are not saved in the workload history.
            }
        }
    }

    static Simulator replay(int[] capacities, SimpleList<WorkloadEvent> events, Algorithm algorithm) {
        // Each run owns fresh servers, requests, containers and a Round Robin index of 0.
        Simulator copy = new Simulator(capacities, algorithm);
        for (int i = 0; i < events.size(); i++) {
            WorkloadEvent event = events.get(i);
            switch (event.type) {
                case "ADD": copy.addRequest(event.requestId, event.value); break;
                case "TIME": copy.advanceTime(event.value); break;
                case "SCALE_ON":
                case "SCALE_OFF":
                    copy.configureAutoscaling(event.type.equals("SCALE_ON"), event.value,
                        Integer.parseInt(event.requestId));
                    break;
                case "FAIL": copy.failServer(event.value); break;
                case "RECOVER": copy.recoverServer(event.value); break;
                default: throw new IllegalArgumentException("Unknown event.");
            }
        }
        return copy;
    }

    private static void compare(int[] capacities, SimpleList<WorkloadEvent> events) {
        if (events.size() == 0) { System.out.println("Add a workload first."); return; }
        Simulator robin, least;
        try {
            robin = replay(capacities, events, Algorithm.ROUND_ROBIN);
            least = replay(capacities, events, Algorithm.LEAST_LOAD);
        } catch (IllegalArgumentException exception) {
            // Different scheduling can create scaled servers at different times.
            System.out.println("Comparison unavailable: this event history cannot be replayed identically.");
            System.out.println("A scaled server may not exist yet, or a later limit may be too small in one run.");
            System.out.println("Try a workload with failures/recoveries limited to initial servers and a fixed scaling limit.");
            return;
        }
        boolean robinFinished = robin.finishWorkload();
        boolean leastFinished = least.finishWorkload();
        System.out.println("\nSame setup and events; each run continues until completion or blockage.");
        System.out.printf("%-25s %-18s %-18s%n", "Metric", "Round Robin", "Least Load");
        comparisonRow("Total servers", "" + robin.servers.size(), "" + least.servers.size());
        comparisonRow("Scaled servers", "" + robin.scaledServers, "" + least.scaledServers);
        comparisonRow("Final time", "" + robin.time, "" + least.time);
        comparisonRow("Completed", "" + robin.completed.size(), "" + least.completed.size());
        comparisonRow("Unfinished", "" + (robin.requests.size() - robin.completed.size()),
            "" + (least.requests.size() - least.completed.size()));
        comparisonRow("Max waiting queue", "" + robin.maximumQueueLength, "" + least.maximumQueueLength);
        comparisonRow("Avg waiting (completed)", average(robin, true), average(least, true));
        comparisonRow("Avg turnaround", average(robin, false), average(least, false));
        if (!robinFinished || !leastFinished)
            System.out.println("INCOMPLETE: no online server. Averages cover completed requests only; no winner declared.");
        System.out.println("Your live simulation is unchanged.");
    }

    private static String average(Simulator s, boolean waiting) {
        if (s.completed.size() == 0) return "N/A";
        long total = waiting ? s.completed.totalWaiting() : s.completed.totalTurnaround();
        return String.format("%.2f", (double) total / s.completed.size());
    }

    private static void comparisonRow(String label, String a, String b) {
        System.out.printf("%-25s %-18s %-18s%n", label, a, b);
    }
}
