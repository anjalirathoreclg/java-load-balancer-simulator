# Updated verification

ProjectTests.java includes the original container, scheduling, failure and replay
checks plus autoscaling limits, toggles, capacity validation, recovery of added
servers, all-offline scale-up, Auto duration/load selection, and replay of scaling
settings. Run `javac *.java` then `java ProjectTests`.

Verified with Java 17: compilation succeeded and all 39 checks passed.
The README menu demo was also executed successfully.
