// All containers below are handwritten. No Java collection classes are used.

// A growable array: used for servers, running requests and recorded events.
class SimpleList<T> {
    private Object[] data = new Object[4];
    private int size = 0;

    int size() { return size; }

    void add(T value) {
        // Double capacity when the backing array becomes full.
        if (size == data.length) {
            Object[] bigger = new Object[data.length * 2];
            for (int i = 0; i < size; i++) bigger[i] = data[i];
            data = bigger;
        }
        data[size++] = value;
    }

    @SuppressWarnings("unchecked")
    T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        return (T) data[index];
    }

    void remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        // Close the gap after deletion, then release the last reference.
        for (int i = index; i < size - 1; i++) data[i] = data[i + 1];
        data[--size] = null;
    }

    void clear() {
        for (int i = 0; i < size; i++) data[i] = null;
        size = 0;
    }
}

// A normal FIFO queue implemented using a singly linked list.
class RequestQueue {
    private static class Node {
        Request value;
        Node next;
        Node(Request value) { this.value = value; }
    }
    private Node front, rear;
    private int size;
    int size() { return size; }
    boolean isEmpty() { return front == null; }

    void enqueue(Request request) {
        Node node = new Node(request);
        if (rear == null) front = node;
        else rear.next = node;
        rear = node;
        size++;
    }

    Request dequeue() {
        if (isEmpty()) return null;
        Request result = front.value;
        front = front.next;
        if (front == null) rear = null;
        size--;
        return result;
    }

    // Read pending durations without exposing linked nodes to the simulator.
    int minimumDuration() {
        int minimum = Integer.MAX_VALUE;
        for (Node n = front; n != null; n = n.next)
            minimum = Math.min(minimum, n.value.remainingTime);
        return minimum;
    }
    int maximumDuration() {
        int maximum = 0;
        for (Node n = front; n != null; n = n.next)
            maximum = Math.max(maximum, n.value.remainingTime);
        return maximum;
    }

    void display() {
        if (isEmpty()) System.out.println("No waiting requests.");
        for (Node node = front; node != null; node = node.next)
            System.out.println(node.value);
    }
}

// A linked stack: push at the top and display without popping.
class CompletionStack {
    private static class Node {
        Request value;
        Node next;
        Node(Request value, Node next) { this.value = value; this.next = next; }
    }
    private Node top;
    private int size;
    int size() { return size; }
    void push(Request request) { top = new Node(request, top); size++; }
    void display() {
        if (top == null) System.out.println("No completed requests.");
        for (Node node = top; node != null; node = node.next) {
            Request r = node.value;
            System.out.println(r + " | turnaround=" + r.turnaround()
                    + " | waiting=" + r.waiting());
        }
    }
    long totalWaiting() {
        long sum = 0;
        for (Node node = top; node != null; node = node.next) sum += node.value.waiting();
        return sum;
    }
    long totalTurnaround() {
        long sum = 0;
        for (Node node = top; node != null; node = node.next) sum += node.value.turnaround();
        return sum;
    }
}

// Hash table with separate chaining: collisions share a linked bucket.
class RequestTable {
    private static class Entry {
        Request value;
        Entry next;
        Entry(Request value, Entry next) { this.value = value; this.next = next; }
    }
    private final Entry[] buckets = new Entry[101];
    private int size;
    int size() { return size; }
    private int bucket(String id) {
        // Keep the hash within the bucket range at each character.
        int hash = 0;
        for (int i = 0; i < id.length(); i++) hash = (hash * 31 + id.charAt(i)) % buckets.length;
        return hash;
    }
    Request get(String id) {
        for (Entry e = buckets[bucket(id)]; e != null; e = e.next)
            if (e.value.id.equals(id)) return e.value;
        return null;
    }
    void put(Request request) {
        if (get(request.id) != null) throw new IllegalArgumentException("Duplicate request ID.");
        int index = bucket(request.id);
        buckets[index] = new Entry(request, buckets[index]);
        size++;
    }
}

// Binary min heap: lower remaining load wins; smaller server ID breaks ties.
class ServerHeap {
    private Server[] data;
    private int size;
    void rebuild(SimpleList<Server> servers) {
        data = new Server[servers.size()];
        size = 0;
        for (int i = 0; i < servers.size(); i++) {
            Server s = servers.get(i);
            if (s.available()) insert(s);
        }
    }
    private boolean less(Server a, Server b) {
        if (a.load() != b.load()) return a.load() < b.load();
        return a.id < b.id;
    }
    private void insert(Server server) {
        int child = size++;
        data[child] = server;
        // Move the new server upward until heap order is restored.
        while (child > 0) {
            int parent = (child - 1) / 2;
            if (!less(data[child], data[parent])) break;
            Server temp = data[parent]; data[parent] = data[child]; data[child] = temp;
            child = parent;
        }
    }
    Server minimum() { return size == 0 ? null : data[0]; }
}
